import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.net.HttpURLConnection;
import static java.net.Proxy.Type.HTTP;
import java.net.URL;
import javax.json.JsonObject;
import javax.json.stream.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static jdk.nashorn.internal.objects.ArrayBufferView.buffer;
import jdk.nashorn.internal.parser.JSONParser;
import org.immutables.gson.Gson;
import org.json.JSONException;
import org.json.JSONObject;


@WebServlet(name = "servlet", urlPatterns = {"/employee/employee/"})
public class EmployeeServlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String requestUrl = request.getRequestURI();
		String id = requestUrl.substring("/employee/employee/".length());
                Employee employee = DataStore.getInstance().getPerson(id);
		if(employee != null){
                        response.setContentType("application/json;charset=UTF-8");
                        ServletOutputStream out = response.getOutputStream();
                       JSONObject output = new JSONObject(employee);  
                       	String json = "{\n";
                        json += "\"id\": " + JSONObject.quote(output.getString("id")) + ",\n";
			json += "\"name\": " + JSONObject.quote(output.getString("name")) + ",\n";
			json += "\"gender\": " + JSONObject.quote(output.getString("gender")) + ",\n";
			json += "\"age\": " + JSONObject.quote(output.getString("age")) + ",\n";
                        json += "\"pic\": " + JSONObject.quote(output.getString("pic")) + "\n";
			json += "}";
                        response.getOutputStream().println(json);
		}
		else{
			
			response.getOutputStream().println("No user found !");
		}
	}
	
	

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
            PrintWriter out = new PrintWriter(System.out); 
            response.setHeader("Content-Type", "application/json");
            response.setContentType("application/json");
            JSONObject jsonObject;
            BufferedReader reader = request.getReader();
    try {
        String line;
        String name = request.getParameter("name");
        while ((line = reader.readLine()) != null) {
            String det = line;
            JSONObject output = new JSONObject(det);
            DataStore.getInstance().putPerson(new Employee(output.getString("id"),output.getString("name"),output.getString("gender"),output.getString("age"),output.getString("pic")));
            response.getOutputStream().println();
           String age = request.getParameter("age");
            String id = request.getParameter("id");
            String gender = request.getParameter("gender");
            String pic = request.getParameter("pic");
            DataStore.getInstance().putPerson(new Employee(id,name,gender,age,pic));
            response.getOutputStream().println("Details Added!");
        }
        
        
            
        
       
    } finally {
        reader.close();
    }
            
    

}
        
        @Override
    	public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
                  PrintWriter out = new PrintWriter(System.out); 
            response.setHeader("Content-Type", "application/json");
            response.setContentType("application/json");
            JSONObject jsonObject;
            BufferedReader reader = request.getReader();
    try {
        String line;
        String name = request.getParameter("name");
        while ((line = reader.readLine()) != null) {
            String det = line;
            JSONObject output = new JSONObject(det);
            response.getOutputStream().println();
            DataStore.getInstance().putPerson(new Employee(output.getString("id"),output.getString("name"),output.getString("gender"),output.getString("age"),output.getString("pic")));
           String age = request.getParameter("age");
            String id = request.getParameter("id");
            String gender = request.getParameter("gender");
            String pic = request.getParameter("pic");
            DataStore.getInstance().putPerson(new Employee(id,name,gender,age,pic));
            response.getOutputStream().println("Details Updated !");
        }
        
        
            
        
       
    } finally {
        reader.close();
    }
    

}    
              @Override
    public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    String requestUrl = request.getRequestURI();
    String id = requestUrl.substring("/employee/employee/".length());  
    response.getOutputStream().println(id);
    DataStore.getInstance().DeletePerson(id);
    response.getOutputStream().println("User deleted !");
    

}
	}
