public class Employee {
        private String id;
	private String name;
	private String age;
	private String gender;
        private String pic;
	
	public Employee(String id,String name, String age, String gender, String pic) {
                this.id = id;
                this.name = name;
		this.age = age;
		this.gender = gender;
                this.pic = pic;
	}
        
        public String getId() {
		return id;
	}
        
	public String getName() {
		return name;
	}

	public String getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}
        
        public String getPic() {
		return pic;
	}
}